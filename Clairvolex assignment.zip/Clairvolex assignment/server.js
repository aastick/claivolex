// server.js

const express = require('express');
const bodyParser = require('body-parser');
const fs = require('fs');

const app = express();
const port = 3000;

// const connection = mysql.createConnection({
//     host: 'localhost',
//     user: 'mysql-user', 
//     password: 'password', 
//     database: 'books_store'
// });

// // Connect to MySQL
// connection.connect(err => {
//     if (err) throw err;
//     console.log('Connected to MySQL database');
// });
// Middleware
app.use(bodyParser.json());

// Route for retrieving books
app.get('/books', (req, res) => {
    const { title, author, startDate, endDate, genre, sortOrder, page, size } = req.query;
    
    // Read data from the JSON file
    fs.readFile('books.json', 'utf8', (err, data) => {
        if (err) {
            console.error('Error reading file:', err);
            res.status(500).json({ error: 'An unexpected error occurred' });
            return;
        }

        try {
            let books = JSON.parse(data);

            // search criteria
            if (title) {
                books = books.filter(book => book.title.toLowerCase().includes(title.toLowerCase()));
            }
            if (author) {
                books = books.filter(book => book.author.toLowerCase().includes(author.toLowerCase()));
            }
            if (startDate && endDate) {
                books = books.filter(book => book.published_date >= startDate && book.published_date <= endDate);
            }
            if (genre) {
                books = books.filter(book => book.genre.toLowerCase() === genre.toLowerCase());
            }
            
            // Apply sort order
            if (sortOrder) {
                books.sort((a, b) => {
                    if (a[sortOrder] < b[sortOrder]) return -1;
                    if (a[sortOrder] > b[sortOrder]) return 1;
                    return 0;
                });
            }

            // Apply pagination
            const startIndex = (page - 1) * size;
            const endIndex = startIndex + size;
            const paginatedBooks = books.slice(startIndex, endIndex);

            res.json(paginatedBooks);
        } catch (error) {
            console.error('Error parsing JSON:', error);
            res.status(500).json({ error: 'An unexpected error occurred' });
        }
    });
});

// Start server
app.listen(port, () => {
    console.log(`Server is running on port ${port}`);
});
